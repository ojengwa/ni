ni
===============================

version number: 0.0.1
author: Bernard Ojengwa

Overview
--------

A microservice-based web framework for Python.

Installation / Usage
--------------------

To install use pip:

    $ pip install .


Or clone the repo:

    $ git clone https://github.com/ojengwa/..git
    $ python setup.py install
    
Contributing
------------

TBD

Example
-------

TBD